from .models import route53_backend
mock_route53 = route53_backend.decorator
