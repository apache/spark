from .models import s3bucket_path_backend
mock_s3bucket_path = s3bucket_path_backend.decorator
