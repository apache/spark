from .models import elb_backend
mock_elb = elb_backend.decorator
