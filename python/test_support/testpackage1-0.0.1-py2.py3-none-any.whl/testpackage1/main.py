"""
Used to test shipping of code depenencies
"""

class TestPackage1Class(object):
    def hello(self):
        return "Hello World from inside a package!"
